let languages = [
    {"id": "zh", type: "from"},
    {"id": "vi", type: "to"}
] 

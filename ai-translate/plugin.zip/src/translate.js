load("language_list.js");

function execute(text) {
    return translateContent(text, 0); // Simplified execute function
}

function translateContent(text, retryCount) {
    if (retryCount > 2) return null;

    // URL dịch thuật mẫu từ Pollinations.AI API (GET)
    const baseURL = 'https://text.pollinations.ai/dịch văn bản sau sang tiếng việt và chỉ hiện bản dịch:';

    // Mã hóa URL văn bản tiếng Trung cần dịch
    const encodedText = encodeURIComponent(text);

    // Tạo URL đầy đủ bằng cách ghép baseURL và văn bản đã mã hóa
    const apiUrl = baseURL + encodedText;

    let response = fetch(apiUrl, { // Sử dụng phương thức GET
        method: 'GET',
    });

    if (response.ok) {
        // Response từ URL này có thể trả về text trực tiếp, không phải JSON
        return response.text()
            .then(translatedText => {
                return Response.success(translatedText.trim()); // Trả về bản dịch đã trim
            });
    } else {
        return translateContent(text, retryCount + 1); // Thử lại nếu lỗi
    }
}
load("language_list.js");

function execute(text) {
    return translateLongText(text, 0); // Gọi hàm dịch văn bản dài
}

function translateLongText(longText, retryCount) {
    if (retryCount > 2) return null;

    const baseURL = 'https://text.pollinations.ai/dịch văn bản sau sang tiếng việt và chỉ hiện bản dịch:';
    const paragraphs = longText.split('\n').filter(p => p.trim() !== ''); // Chia theo đoạn văn
    let translatedParagraphs = [];
    let errorOccurred = false;

    for (const paragraph of paragraphs) {
        const encodedText = encodeURIComponent(paragraph);
        const apiUrl = baseURL + encodedText;

        let response = fetch(apiUrl, { method: 'GET' });

        try {
            const responseData = await response;
            if (responseData.ok) {
                const translatedText = await responseData.text();
                translatedParagraphs.push(translatedText.trim());
            } else {
                console.error("Lỗi Pollinations.AI API (đoạn văn):", responseData.status, responseData.statusText);
                errorOccurred = true;
                break;
            }
        } catch (error) {
            console.error("Lỗi Fetch API (đoạn văn):", error);
            errorOccurred = true;
            break;
        }
    }

    if (!errorOccurred) {
        const fullTranslatedText = translatedParagraphs.join('\n\n'); // Ghép các đoạn đã dịch
        return Response.success(fullTranslatedText);
    } else {
        return translateLongText(longText, retryCount + 1); // Thử lại nếu lỗi
    }
}